package stickhero;

public interface WalkAssist {
    void shift() throws ObjectTransitionException;
}
